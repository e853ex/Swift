//
//  ViewController1.swift
//  Lesson1
//
//  Created by Сергей Васильев on 23.10.2020.
//

import UIKit

class ViewController1: UIViewController {
    
    @IBOutlet weak var welcome: UILabel!
    
}
